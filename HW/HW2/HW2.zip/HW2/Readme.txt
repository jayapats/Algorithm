In order to execute in the server type the below commands
Folder - CS325 -> HW2

Q5 - 

a. File name - Merge3File.java

It can be run as below :
javac Merge3File.java
java Merge3File

b. File name - Merge3Time.java

It can be run as below :
javac Merge3Time.java
java Merge3Time



