Problem 4:
File Name - MinSpanningTree

In order to execute the program, run the following commands 

javac MinSpanningTree.java
java MinSpanningTree graph.txt