In order to execute in the server type the below commands
Folder - CS325 -> HW3

3c - 
program to collect the running time
File name - Knapsack.java

It can be run as below :
javac Knapsack.java
java Knapsack

4c
File name - Shopping.java

It can be run as below :
javac Shopping.java
java Shopping



